package com.example.sabittahsin.trydatabasepro;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.Toast;


/**
 * Created by Sabit Tahsin on 27-Sep-18.
 */

public class MyDatabaseHelper extends SQLiteOpenHelper {

    public static final String DATABASE_NAME = "Student.db";
    public static final String TABLE_NAME = "info_table";
    public static final String SERIAL = "serial";
    public static final String ID = "id";
    public static final String NAME = "name";
    public static final String DEPT = "dept";
    public static final String YEAR = "year";
    public static final int version = 1;
    Context context;


    public MyDatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, version);
        this.context = context;
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        String sql = "create table info_table(serial integer primary key autoincrement,id integer,name varchar(30),dept varchar(20),year varchar(10));";
        try {
            sqLiteDatabase.execSQL(sql);
            Toast.makeText(context, "onCreate is called", Toast.LENGTH_SHORT).show();
        }catch (Exception e){
            Toast.makeText(context, "Failed!!", Toast.LENGTH_SHORT).show();
        }

    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        String sql = "drop table if exits info_table";
        onCreate(sqLiteDatabase);
    }


    public long insertData(int id,String name,String dept,String year){
        long rowId;
        SQLiteDatabase sqliteDatabase = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(ID,id);
        contentValues.put(NAME,name);
        contentValues.put(DEPT,dept);
        contentValues.put(YEAR,year);
        rowId = sqliteDatabase.insert(TABLE_NAME,null,contentValues);
        return rowId;
    }

    public Cursor viewAllData(){
        SQLiteDatabase sqliteDatabase = this.getWritableDatabase();
        String sql = "select * from info_table";
        Cursor cursor = sqliteDatabase.rawQuery(sql,null);
        return cursor;

    }


    public int updateData(int id,String name,String dept,String year,int serial){
        SQLiteDatabase sqliteDatabase = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(ID,id);
        contentValues.put(NAME,name);
        contentValues.put(DEPT,dept);
        contentValues.put(YEAR,year);
        int i = sqliteDatabase.update("info_table",contentValues,SERIAL+" = ?",new String[] {String.valueOf(serial)});
        return i;
    }


    public  int deleteData(int serial){
        SQLiteDatabase sqliteDatabase = this.getWritableDatabase();
        int i = sqliteDatabase.delete("info_table",SERIAL+" = ? ",new String[] {String.valueOf(serial)});
        return  i;
    }

    public  Cursor updatePre(int serial){
        SQLiteDatabase sqliteDatabase = this.getWritableDatabase();
        String sql = "select * from info_table where serial = "+serial;
        Cursor cursor = sqliteDatabase.rawQuery(sql,null);
        return cursor;
    }

}
