 package com.example.sabittahsin.trydatabasepro;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

 public class Main2Activity extends AppCompatActivity {

     EditText idEt,nameEt,deptEt,yearEt,searchEt,updateET;
     Button updateFinalBtn;
     int serialG;

    MyDatabaseHelper myDatabaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        myDatabaseHelper = new MyDatabaseHelper(this);
        SQLiteDatabase sqLiteDatabase = myDatabaseHelper.getWritableDatabase();
        sqLiteDatabase = myDatabaseHelper.getReadableDatabase();


        idEt = (EditText) findViewById(R.id.editText);
        nameEt = (EditText) findViewById(R.id.editText2);
        deptEt = (EditText) findViewById(R.id.editText3);
        yearEt = (EditText) findViewById(R.id.editText4);
        searchEt = (EditText) findViewById(R.id.editText5);
        updateET = (EditText) findViewById(R.id.editText6);

        updateFinalBtn = (Button) findViewById(R.id.button);

        final int serial = Integer.parseInt(getIntent().getStringExtra("serial").toString());

        serialG = serial;
    //    Toast.makeText(this, "Ok : "+serial, Toast.LENGTH_SHORT).show();

        Cursor cursor = myDatabaseHelper.updatePre(serial);
        if(cursor.getCount() == 0){

        }

        while(cursor.moveToNext()) {

           // Toast.makeText(Main2Activity.this, "Name : " + cursor.getString(2).toString(), Toast.LENGTH_SHORT).show();
            idEt.setText(""+cursor.getInt(1));
            nameEt.setText(""+cursor.getString(2));
            deptEt.setText(""+cursor.getString(3));
            yearEt.setText(""+cursor.getString(4));
        }

        updateFinalBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int id = Integer.parseInt(idEt.getText().toString());
                String name = nameEt.getText().toString();
                String dept = deptEt.getText().toString();
                String year = yearEt.getText().toString();
                long check = myDatabaseHelper.updateData(id,name,dept,year,serialG);

                if(check != -1){
                    Toast.makeText(Main2Activity.this, "Update Successful!!!!!", Toast.LENGTH_LONG).show();
                    nameEt.setText(null);
                    deptEt.setText(null);
                    yearEt.setText(null);
                    idEt.setText(null);
                }
                else{
                    Toast.makeText(Main2Activity.this, "Update Failed!!", Toast.LENGTH_LONG).show();
                }
            }
        });


    }
}
