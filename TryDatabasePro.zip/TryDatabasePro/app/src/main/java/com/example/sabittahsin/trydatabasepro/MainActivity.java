package com.example.sabittahsin.trydatabasepro;

import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    EditText idEt,nameEt,deptEt,yearEt,deleteEt,updateET,seachEt;
    Button insertBtn,showDataBtn,deleteBtn,updateBtn,seachBtn;

    MyDatabaseHelper myDatabaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        myDatabaseHelper = new MyDatabaseHelper(this);
        final SQLiteDatabase sqLiteDatabase = myDatabaseHelper.getWritableDatabase();

        idEt = (EditText) findViewById(R.id.editText);
        nameEt = (EditText) findViewById(R.id.editText2);
        deptEt = (EditText) findViewById(R.id.editText3);
        yearEt = (EditText) findViewById(R.id.editText4);
        deleteEt = (EditText) findViewById(R.id.editText5);
        updateET = (EditText) findViewById(R.id.editText6);
        seachEt = (EditText) findViewById(R.id.editText7);

        insertBtn = (Button) findViewById(R.id.button);
        showDataBtn = (Button) findViewById(R.id.button2);
        deleteBtn = (Button) findViewById(R.id.button3);
        updateBtn = (Button) findViewById(R.id.button4);
        seachBtn = (Button) findViewById(R.id.button5);


        insertBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                    int id = Integer.parseInt(idEt.getText().toString());
                    String name = nameEt.getText().toString();
                    String dept = deptEt.getText().toString();
                    String year = yearEt.getText().toString();
                    long rowId = myDatabaseHelper.insertData(id,name,dept,year);

                    if(rowId == -1){
                        Toast.makeText(MainActivity.this, "Insert Data Failed!!", Toast.LENGTH_SHORT).show();
                    }
                    else{
                        Toast.makeText(MainActivity.this, "Insert Data Successful!!", Toast.LENGTH_SHORT).show();
                    }


            }
        });


        showDataBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
               Cursor cursor =  myDatabaseHelper.viewAllData();
                if(cursor.getCount() == 0){
                    return;
                }

                StringBuffer stringBuffer = new StringBuffer();
                while(cursor.moveToNext()){
                    stringBuffer.append("Serial : "+cursor.getInt(0)+"\n");
                    stringBuffer.append("Id : "+cursor.getInt(1)+"\n");
                    stringBuffer.append("Name : "+cursor.getString(2).toString()+"\n");
                    stringBuffer.append("Dept : "+cursor.getString(3).toString()+"\n");
                    stringBuffer.append("Year : "+cursor.getString(4).toString()+"\n\n");
                }

                String s = stringBuffer.toString();

                AlertDialog.Builder alert = new AlertDialog.Builder(MainActivity.this);
                alert.setTitle("All Data");
                alert.setMessage(s);
                alert.setCancelable(true);
                alert.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        dialogInterface.cancel();
                    }
                });
                alert.show();


            }
        });


        updateBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

              //  int serial = Integer.parseInt(updateET.getText().toString());
                Intent intent = new Intent(MainActivity.this,Main2Activity.class);
                intent.putExtra("serial",updateET.getText().toString());
                startActivity(intent);




                /*
                int id = Integer.parseInt(idEt.getText().toString());
                String name = nameEt.getText().toString();
                String dept = deptEt.getText().toString();
                String year = yearEt.getText().toString();
                String updateName = updateET.getText().toString();
                int check = myDatabaseHelper.updateData(id,name,dept,year,updateName);

                if(check != -1){
                    Toast.makeText(MainActivity.this, "Update Successful!!!!!", Toast.LENGTH_SHORT).show();
                }
                else{
                    Toast.makeText(MainActivity.this, "Update Failed!!", Toast.LENGTH_SHORT).show();
                }


                */
            }
        });


        deleteBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int serial = Integer.parseInt(deleteEt.getText().toString());
                int check = myDatabaseHelper.deleteData(serial);
                if(check != -1){
                    Toast.makeText(MainActivity.this, "Delete Successful!!!!!", Toast.LENGTH_SHORT).show();
                }
                else{
                    Toast.makeText(MainActivity.this, "Delete Failed!!", Toast.LENGTH_SHORT).show();
                }
            }
        });


        seachBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int serial = Integer.parseInt(seachEt.getText().toString());
                Cursor cursor = myDatabaseHelper.updatePre(serial);
                if(cursor.getCount() == 0){

                }
                while (cursor.moveToNext()){
                    Toast.makeText(MainActivity.this, " Result : "+cursor.getString(3).toString(), Toast.LENGTH_LONG).show();
                }
            }
        });


    }
}
